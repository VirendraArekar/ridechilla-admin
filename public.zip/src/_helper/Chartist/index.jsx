import { createContext } from 'react';

const ChartistContext = createContext();

export default ChartistContext;
