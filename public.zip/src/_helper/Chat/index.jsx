import { createContext } from 'react';

const ChatAppContext = createContext();

export default ChatAppContext;
