import { createContext } from 'react';

const TodoContext = createContext();

export default TodoContext;
