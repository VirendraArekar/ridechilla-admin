import { createContext } from 'react';

const KanbanContext = createContext();

export default KanbanContext;