import { createContext } from 'react';

const JobSearchContext = createContext();

export default JobSearchContext;
