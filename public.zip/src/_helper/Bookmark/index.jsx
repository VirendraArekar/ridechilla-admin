import { createContext } from 'react';

const BookmarkContext = createContext();

export default BookmarkContext;
