import { createContext } from 'react';

const ChartjsContext = createContext();

export default ChartjsContext;
